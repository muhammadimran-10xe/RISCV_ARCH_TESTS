# RISC-V mstatus.FS field behaviour verification Test (Task 4)

## Overview
this test verifies the correct behavior of the mstatus.FS (Floating-Point Status) field and the mstatus.SD (State Dirty) bit in Machine mode of the RISC-V privileged architecture specification.

---

## File Structure
├── docs/
| ├── muhammdimran_task4.pdf
├── src/
│ ├── test.S # Main assembly test
│ └── link.ld # Linker script
├── logs/
│ ├── test.elf # Compiled ELF
│ ├── test.dis # Disassembly
│ ├── spike.log # Spike execution log 
│ ├── spike.out # Spike output 
│ └── test.signature.output # Signature file
├── Makefile
├── README.md

## Build and Run Instructions

### Build
make build

### Run on Spike
make run

### Debug on Spike
make debug

### Read ELF file
make read_elf

### Clean Generated files
make clean

### clean build and run on Spike

make all

## Reference

Extension Context Status in mstatus Register: RISCV Privileged Architecture v1.12, 3.1.6.6

## Author
Muhammad Imran
Task 4 – RISC-V mstatus.FS field behaviour verification test
